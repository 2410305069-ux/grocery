---
name: Verdant Market
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#404943'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#707973'
  outline-variant: '#bfc9c1'
  surface-tint: '#2c694e'
  primary: '#003925'
  on-primary: '#ffffff'
  primary-container: '#0f5238'
  on-primary-container: '#85c4a2'
  inverse-primary: '#95d4b2'
  secondary: '#2b694d'
  on-secondary: '#ffffff'
  secondary-container: '#b0f1cd'
  on-secondary-container: '#327053'
  tertiary: '#203627'
  on-tertiary: '#ffffff'
  tertiary-container: '#364d3c'
  on-tertiary-container: '#a3bda7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b0f1cd'
  primary-fixed-dim: '#95d4b2'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#0d5137'
  secondary-fixed: '#b0f1cd'
  secondary-fixed-dim: '#95d4b2'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#0d5137'
  tertiary-fixed: '#cee9d2'
  tertiary-fixed-dim: '#b3cdb7'
  on-tertiary-fixed: '#092012'
  on-tertiary-fixed-variant: '#354c3b'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
  success-container: '#b0f1cc'
  on-success-container: '#327053'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  container-margin: 20px
---

## Brand & Style
Verdant Market is a fresh-focused grocery experience that blends **Modern Corporate** reliability with **Minimalist** clarity. The brand personality is wholesome, efficient, and transparent, aimed at health-conscious urban dwellers who value quality and speed. 

The visual style utilizes a "Clean Fidelity" approach: high-resolution product photography set against an ultra-clean, neutral backdrop, allowing the natural colors of the food to provide the primary visual interest. The interface remains unobtrusive, using subtle borders and soft tonal shifts rather than heavy shadows or decorative elements.

## Colors
The palette is rooted in deep, "Forestry" greens that evoke freshness and organic quality. 

- **Primary Green (#0f5238):** Used for key actions and brand identity.
- **Secondary Mint (#b0f1cc):** Utilized for high-frequency interaction points like "Add to Cart" buttons to provide a soft, welcoming touch.
- **Surface Strategy:** We use a multi-tiered neutral system. The base background is a cool-toned off-white (`#f8f9fa`), while interactive cards sit on pure white (`#ffffff`) to pop against the subtle background.
- **Semantic Accents:** Red is reserved strictly for urgent notifications (e.g., cart counts or alerts), while muted earth tones are used for category tagging (e.g., "Organic" or "High Protein").

## Typography
The system uses a pairing of **Plus Jakarta Sans** for expressive headings and **Inter** for functional UI elements.

- **Headlines:** Set in Plus Jakarta Sans with tighter letter-spacing and bold weights to feel modern and friendly. 
- **Functional Text:** Inter is used for all body copy, product labels, and prices. Its high x-height ensures readability at small sizes on mobile screens.
- **Pricing:** Always uses `label-md` or `label-sm` with a semi-bold weight to ensure financial information is clear and immediate.

## Layout & Spacing
The layout follows a **Fluid Grid** approach with strict horizontal margins.

- **Margins:** A standard `container-margin` of 20px is used for mobile views to provide breathing room.
- **Grid:** For desktop, content is centered within a 768px (md) max-width container.
- **Horizontal Scroll:** Lists (Categories, Products) use horizontal overflow with `snap-x` alignment to allow high-density content discovery without excessive vertical scrolling.
- **Vertical Rhythm:** Sections are separated by `md` (16px) or `lg` (24px) gaps to maintain a clear visual hierarchy between "Popular Snacks," "Dairy," etc.

## Elevation & Depth
This system relies on **Tonal Layers** and **Low-Contrast Outlines** rather than traditional shadows.

- **Levels:** 
    - **Level 0 (Background):** `#f8f9fa` (Surface).
    - **Level 1 (Cards/Inputs):** `#ffffff` (Surface Lowest) with a 1px border of `#bfc9c1` (Outline Variant).
    - **Level 2 (Sticky Headers):** Same as Level 1 but with a 20% opacity bottom-only border to signify separation during scroll.
- **Interaction:** On hover or active state, cards do not lift; instead, their border color transitions to the Primary Green, and a subtle scale-down effect (95-98%) provides tactile feedback.
- **Shadows:** Only used on the Bottom Navigation bar (`rgba(0,0,0,0.04)`) to ensure it remains visible over scrolling content.

## Shapes
The shape language is **Rounded**, balancing professional structure with organic softness.

- **Standard Elements:** Cards and featured banners use `rounded-xl` (1.5rem / 24px) to feel modern and high-end.
- **Buttons & Inputs:** Search bars and primary action buttons use a **Full Pill** shape to emphasize interactability and friendliness.
- **Icon Containers:** Category icons are housed in perfect circles to create a rhythmic, repetitive pattern in horizontal scrolls.

## Components
- **Buttons:** 
    - **Primary:** Pill-shaped, Primary Green background with White text.
    - **Add-to-Cart:** Small circular buttons (32x32px) using Secondary Green (`#b0f1cc`) with a plus icon.
- **Cards:** 
    - White background, 1px border. Product cards feature a distinct gray header area for the image to provide a "frame" effect.
- **Chips/Badges:** 
    - Tiny labels (10px) with 4px padding, used for product attributes like "Organic" or "Spicy." They use container-tonal pairings (e.g., Tertiary background for organic).
- **Search Bar:** 
    - Full-width, pill-shaped, with a 1px outline and left-aligned icon. Uses Inter `body-md` for placeholder text.
- **Navigation:** 
    - Mobile-first bottom bar with active states indicated by a tonal background "pill" behind the icon, following Material 3 logic.